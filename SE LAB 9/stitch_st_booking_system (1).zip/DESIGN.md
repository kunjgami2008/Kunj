---
name: ST Booking System
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#43474f'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#737780'
  outline-variant: '#c3c6d1'
  surface-tint: '#3a5f94'
  primary: '#001e40'
  on-primary: '#ffffff'
  primary-container: '#003366'
  on-primary-container: '#799dd6'
  inverse-primary: '#a7c8ff'
  secondary: '#0050cc'
  on-secondary: '#ffffff'
  secondary-container: '#0266ff'
  on-secondary-container: '#f9f7ff'
  tertiary: '#1b1f20'
  on-tertiary: '#ffffff'
  tertiary-container: '#303436'
  on-tertiary-container: '#999c9e'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d5e3ff'
  primary-fixed-dim: '#a7c8ff'
  on-primary-fixed: '#001b3c'
  on-primary-fixed-variant: '#1f477b'
  secondary-fixed: '#dae1ff'
  secondary-fixed-dim: '#b3c5ff'
  on-secondary-fixed: '#001849'
  on-secondary-fixed-variant: '#003fa4'
  tertiary-fixed: '#e0e3e5'
  tertiary-fixed-dim: '#c4c7c9'
  on-tertiary-fixed: '#191c1e'
  on-tertiary-fixed-variant: '#444749'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Manrope
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 40px
  xl: 64px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 48px
---

## Brand & Style
The design system is rooted in **Corporate Modernism**, emphasizing efficiency, reliability, and precision. It is built for a professional user base that requires high-utility booking workflows. The emotional response should be one of confidence and calm; the UI should never feel cluttered or overwhelming, even when handling complex data.

Key pillars of the aesthetic include:
- **Functional Minimalism:** Every element must serve a clear purpose.
- **Precision:** Perfect alignment and consistent rhythm to reinforce a sense of order.
- **Trustworthiness:** A balanced use of high-quality typography and a sophisticated corporate palette.

## Colors
The palette is centered around a "Deep Navy" primary for authority and a "Vibrant Corporate Blue" for action and interaction. 

- **Primary (#003366):** Used for navigation backgrounds, primary headings, and brand-critical elements.
- **Secondary (#0066FF):** The primary action color for buttons, links, and active states.
- **Neutral Grays:** A range of Slate grays (from #0F172A for text to #F8FAFC for backgrounds) are used to maintain high legibility and soft structural division.
- **Semantic Colors:** Success (Emerald), Warning (Amber), and Error (Rose) should be used sparingly for status indicators in the booking flow.

## Typography
This design system utilizes a dual-font approach to balance personality with utility. 

**Manrope** is used for headlines to provide a modern, slightly geometric warmth that remains professional. **Inter** is the workhorse for all body copy, inputs, and labels due to its exceptional legibility in data-dense interfaces and high x-height. 

- Use `headline-xl` only for main dashboard overviews.
- All body text should default to `body-md`.
- Use `label-md` for table headers and small eyebrow text to create clear hierarchy.

## Layout & Spacing
The layout follows a **8px linear scale** to ensure visual harmony across all components.

- **Grid:** Use a 12-column fluid grid for desktop with 24px gutters. For mobile, transition to a single-column layout with 16px side margins.
- **Booking Flow Layout:** Use a "Centered Focused" layout for booking steps to minimize eye travel, typically constrained to a max-width of 800px.
- **Dashboard Layout:** Utilize a fixed left-hand navigation (240px) with a fluid content area for scheduling and management tasks.

## Elevation & Depth
Depth is conveyed through **Ambient Shadows** and **Tonal Layering**. This creates a sense of "objects on a desk" without looking dated.

- **Level 0 (Base):** Background color (#F8FAFC). No shadow.
- **Level 1 (Cards):** White background with a subtle, highly diffused shadow: `0px 4px 12px rgba(0, 0, 0, 0.05)`.
- **Level 2 (Popovers/Dropdowns):** White background with a medium shadow: `0px 8px 24px rgba(0, 0, 0, 0.10)`.
- **Interactions:** Hovering over a card should slightly increase its elevation (Level 2) and add a subtle 1px border stroke in the secondary color.

## Shapes
The shape language is "Soft-Professional." By using a **Rounded (0.5rem)** base, the UI feels approachable and contemporary but maintains enough structural rigidity to be taken seriously as a business tool.

- **Inputs & Small Buttons:** Use `rounded` (8px).
- **Cards & Modals:** Use `rounded-lg` (16px).
- **Status Badges/Chips:** Use `rounded-xl` (24px) for a pill-style look that distinguishes them from actionable buttons.

## Components
- **Buttons:** Primary buttons use the Secondary Blue (#0066FF) with white text. Ghost buttons use a Slate-400 border. Transitions should be a fast 150ms ease-in-out.
- **Inputs:** Fields must have a clear 1px border (#E2E8F0). The focus state uses a 2px offset ring in the secondary color.
- **Cards:** Use cards to group booking details. Every card should have a 16px internal padding (space-md).
- **Calendar/DatePicker:** The most critical component. Days should be presented in a clean grid with the "Current Day" highlighted in the primary navy and "Selected Range" in a 10% opacity version of the secondary blue.
- **Lists:** Use subtle horizontal dividers (#F1F5F9) instead of boxes for list items to maintain whitespace.
- **Chips:** Used for "Confirmed," "Pending," and "Canceled" statuses. Use low-saturation background colors with high-saturation text for maximum readability without visual noise.